#include "InventoryManager.h"

#include <iostream>
#include <iomanip>
#include <algorithm>
#include <vector>
#include <string>
#include <limits>

/* ------------------------------------------------------------------ *
 * Constructor / destructor                                             *
 * ------------------------------------------------------------------ */

InventoryManager::InventoryManager() {}
InventoryManager::~InventoryManager() {}

/* ------------------------------------------------------------------ *
 * Private input helpers                                                *
 * ------------------------------------------------------------------ */

static void clear_input()
{
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

static int prompt_positive_id(const std::string &prompt)
{
    int id;
    while (true) {
        std::cout << prompt;
        if (std::cin >> id && id > 0) { clear_input(); return id; }
        std::cout << "  [!] ID must be a positive integer. Try again.\n";
        clear_input();
    }
}

static int prompt_quantity(const std::string &prompt)
{
    int q;
    while (true) {
        std::cout << prompt;
        if (std::cin >> q && q >= 0) { clear_input(); return q; }
        std::cout << "  [!] Quantity must be 0 or more. Try again.\n";
        clear_input();
    }
}

static float prompt_price(const std::string &prompt)
{
    float p;
    while (true) {
        std::cout << prompt;
        if (std::cin >> p && p >= 0.0f) { clear_input(); return p; }
        std::cout << "  [!] Price must be 0 or more. Try again.\n";
        clear_input();
    }
}

static std::string prompt_name(const std::string &prompt)
{
    std::string name;
    while (true) {
        std::cout << prompt;
        std::getline(std::cin, name);
        if (!name.empty()) return name;
        std::cout << "  [!] Name must not be empty. Try again.\n";
    }
}

/* ------------------------------------------------------------------ *
 * Public CRUD wrappers                                                 *
 * ------------------------------------------------------------------ */

void InventoryManager::addItem()
{
    std::cout << "\n--- Add Item ---\n";
    Item item{};
    item.id         = prompt_positive_id("  Enter ID       : ");
    std::string nm  = prompt_name       ("  Enter name     : ");
    item.quantity   = prompt_quantity   ("  Enter quantity : ");
    item.price      = prompt_price      ("  Enter price    : ");
    item.is_deleted = 0;

    /* Safely copy name into the fixed-size char array */
    nm.resize(NAME_LEN - 1);
    nm.copy(item.name, nm.size());
    item.name[nm.size()] = '\0';

    if (add_item(&item))
        std::cout << "  [OK] Item " << item.id << " added.\n";
    else
        std::cout << "  [FAIL] Could not add item (duplicate ID or I/O error).\n";
}

void InventoryManager::viewItem()
{
    std::cout << "\n--- View Item ---\n";
    int id = prompt_positive_id("  Enter ID to view: ");
    Item item{};
    if (get_item(id, &item)) {
        printHeader();
        printRow(item);
    } else {
        std::cout << "  [FAIL] Item not found or has been deleted.\n";
    }
}

void InventoryManager::updateItem()
{
    std::cout << "\n--- Update Item ---\n";
    int id = prompt_positive_id("  Enter ID to update: ");

    Item existing{};
    if (!get_item(id, &existing)) {
        std::cout << "  [FAIL] Item not found or has been deleted.\n";
        return;
    }

    std::cout << "  Current name     : " << existing.name     << "\n";
    std::cout << "  Current quantity : " << existing.quantity  << "\n";
    std::cout << "  Current price    : " << existing.price     << "\n";

    Item updated{};
    updated.id         = id;
    updated.is_deleted = 0;

    std::string nm   = prompt_name    ("  New name        : ");
    updated.quantity = prompt_quantity("  New quantity    : ");
    updated.price    = prompt_price   ("  New price       : ");

    nm.resize(NAME_LEN - 1);
    nm.copy(updated.name, nm.size());
    updated.name[nm.size()] = '\0';

    if (update_item(id, &updated))
        std::cout << "  [OK] Item " << id << " updated.\n";
    else
        std::cout << "  [FAIL] Could not update item.\n";
}

void InventoryManager::deleteItem()
{
    std::cout << "\n--- Delete Item ---\n";
    int id = prompt_positive_id("  Enter ID to delete: ");
    if (delete_item(id))
        std::cout << "  [OK] Item " << id << " deleted.\n";
    else
        std::cout << "  [FAIL] Item not found or already deleted.\n";
}

void InventoryManager::listItems()
{
    std::cout << "\n--- List All Items ---\n";

    /* STL vector to hold results from the C layer */
    const int MAX = 1024;
    std::vector<Item> buf(MAX);

    int count = list_items(buf.data(), MAX);
    if (count == 0) {
        std::cout << "  (No active items found.)\n";
        return;
    }
    buf.resize(count);

    /* STL sort by ID */
    std::sort(buf.begin(), buf.end(),
              [](const Item &a, const Item &b){ return a.id < b.id; });

    printHeader();
    for (const auto &item : buf)
        printRow(item);

    std::cout << "  Total: " << count << " item(s).\n";
}

/* ------------------------------------------------------------------ *
 * Formatting helpers                                                   *
 * ------------------------------------------------------------------ */

void InventoryManager::printHeader() const
{
    std::cout << "\n"
              << std::left
              << std::setw(6)  << "ID"
              << std::setw(42) << "Name"
              << std::setw(12) << "Quantity"
              << std::setw(10) << "Price"
              << "\n"
              << std::string(70, '-') << "\n";
}

void InventoryManager::printRow(const Item &item) const
{
    std::cout << std::left
              << std::setw(6)  << item.id
              << std::setw(42) << item.name
              << std::setw(12) << item.quantity
              << std::fixed << std::setprecision(2)
              << std::setw(10) << item.price
              << "\n";
}

/* ------------------------------------------------------------------ *
 * Main menu loop                                                       *
 * ------------------------------------------------------------------ */

void InventoryManager::run()
{
    while (true) {
        std::cout << "\n=============================\n";
        std::cout << "   Hybrid Inventory Manager  \n";
        std::cout << "=============================\n";
        std::cout << "  1. Add item\n";
        std::cout << "  2. View item\n";
        std::cout << "  3. Update item\n";
        std::cout << "  4. Delete item\n";
        std::cout << "  5. List all items\n";
        std::cout << "  6. Exit\n";
        std::cout << "-----------------------------\n";
        std::cout << "  Choice: ";

        int choice;
        if (!(std::cin >> choice)) {
            clear_input();
            std::cout << "  [!] Invalid input.\n";
            continue;
        }
        clear_input();

        switch (choice) {
            case 1: addItem();    break;
            case 2: viewItem();   break;
            case 3: updateItem(); break;
            case 4: deleteItem(); break;
            case 5: listItems();  break;
            case 6:
                std::cout << "\n  Goodbye!\n\n";
                return;
            default:
                std::cout << "  [!] Please choose 1-6.\n";
        }
    }
}
