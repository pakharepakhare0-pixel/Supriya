#pragma once

#include "inventory.h"   /* Item struct + C API */

#include <vector>

class InventoryManager {
public:
    InventoryManager();
    ~InventoryManager();

    /* Menu entry points */
    void run();

private:
    void addItem();
    void viewItem();
    void updateItem();
    void deleteItem();
    void listItems();

    /* Formatting */
    void printHeader() const;
    void printRow(const Item &item) const;
};
